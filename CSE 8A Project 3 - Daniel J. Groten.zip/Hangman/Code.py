#When you run the code, get a friend to enter a lowercase word into the terminal.
#Once they enter a word, continue to guess letters until you either win or lose.

remaining_guesses = 10

def take_solution():
    word = input("Enter a word: ")
    print("\n"*20)
    solution = list(word)
    return solution

solution = take_solution()

def setup():
    length = 0
    for i in range(len(solution)):
        length += 1
    print("The word is " + str(length) + " letters long.")
    print("You have " + str(remaining_guesses) + " guesses.")
    board = ["_"]*length
    return board

board = setup()

def update_board():
    while remaining_guesses > 0:
        guess = take_guess()
        if guess in solution:
            if correct_guess() == True:
                break
            else:
                continue
        else:
            if incorrect_guess() == True:
                break
            else:
                continue
    end_game()

def take_guess():
    global guess
    guess = input("Enter a letter: ")
    return guess

def correct_guess():
    for i in range(len(solution)):
        if solution[i] == guess:
            board[i] = guess
    if check_win() == True:
        print(board)
        print("You win!")
        return True
    else:
        if remaining_guesses != 1:
            print("Correct! You have " + str(remaining_guesses) + " guesses left.")
            print(board)
            return False
        else:
            print("Correct! You have 1 guess left.")
            print(board)
            return False
    
def incorrect_guess():
    global remaining_guesses
    remaining_guesses -= 1
    if remaining_guesses == 0:
        print("You lose.")
        return True
    else:
        if remaining_guesses != 1:
            print("Incorrect. You have " + str(remaining_guesses) + " guesses left.")
            print(board)
            return False
        else:
            print("Incorrect. You have 1 guess left.")
            print(board)
            return False

def check_win():
    if board == solution:
        return True
    else:
        return False

def end_game():
    print("The word was " + ''.join(solution) + ".")
    if remaining_guesses != 1:
        print("You had " + str(remaining_guesses) + " guesses remaining.")
    else:
        print("You had 1 guess remaining.")

update_board()